---
name: import-ego
description: Crea un E.G.O desde EGO/TEMPLATE si no existe, trae sus archivos (arte, atlas, sfx y voces) de la carpeta pública de Drive "Limbus Company - Organized Assets" y el gif del idle de su Corrosion de la wiki.gg, los indexa en su sprites.json (atlases, sprites, sfx, voice, idle) y rehace el zip. Úsala al empezar un E.G.O nuevo o cuya carpeta solo tiene la plantilla.
---

# Importar los archivos de un E.G.O

Antes de nada, lee `forbidden.md`, `EGO.md#el-paquete` y `animations.md#ego-su-spritesjson` (formato de `sprites.json`). Las animaciones de las monedas (`animations`) no son parte de esto: se hacen luego con el Animator (`Animator.md#ego`). Las stats de `EGO.xml` (pecado, base, monedas, coste, pasivas, resistencias) tampoco: las pone el usuario con el editor de IDs (`IdentityEditor.md#ego`).

Las rutas de esta skill (`forbidden.md`, `Python/gif2sheet.py`, `EGO/TEMPLATE`...) son desde la raíz del repo de Bingus, no desde la carpeta de la skill: puede estar instalada fuera del repo, desde su zip.

Es la hermana de la skill `import-identity`: mismo Drive, misma wiki y los mismos `index`, `sprites` y `zip` (los de `import_identity.py`, que distinguen un E.G.O por su `EGO.xml`). El zip de esta skill lleva una copia de `import_identity.py` al lado de `import_ego.py`, así que funciona sin tener instalada `import-identity`; en el repo, usa el de `Claude/Skills/import-identity`.

## De dónde sale cada cosa

**El conector de Google Drive no sirve** (solo ve lo que el usuario ya ha abierto). La carpeta es pública y se lee sin login: listar con `https://drive.google.com/embeddedfolderview?id=<carpeta>`, bajar con `https://drive.google.com/uc?export=download&id=<archivo>`. Raíz: `1Nk9WWMxEcovs5Ewku5ICT1PbfByNcV_z`.

Cada pecador tiene una carpeta `EGO/<E.G.O>/` en las cuatro ramas. `<num>` es el número del E.G.O (Crow's Eye View `20101`, Wishing Cairn `20103`, Representation Emitter `20201`); `fetch` lo saca del arte. Mapeo comprobado por hash con Wishing Cairn y Crow's Eye View:

| En el E.G.O | En Drive | Notas |
|---|---|---|
| `images/portrait.png` | Images/Identity & EGO Art/`<Pecador>`/EGO/`<E.G.O>`/`<num>_awaken_info.png` | Algunos E.G.O nuevos no lo traen (Bygone Days) |
| `images/profile.png` | …/`<num>_awaken_profile.png` | |
| `images/thumb.png` | …/`<num>_cg.png` | |
| `images/summary.png` | …/`<num>_profile_summary.png` | No el `_ego_passiveBanner` |
| `images/corrosion_portrait.png` | …/`<num>_erosion_info.png` | Solo con Corrosion |
| `images/corrosion_profile.png` | …/`<num>_erosion_profile.png` | Solo con Corrosion |
| `images/corrosion_thumb.png` | …/`<num>_e_cg.png` (o `_cg_e`, Dimension Shredder) | Solo con Corrosion |
| `images/sprites/sactx-*.png` | Images/Sprites/Sinners/`<Pecador>`/EGO/`<E.G.O>`/ | **Solo el primer nivel**: la subcarpeta `A/` son piezas sueltas y no se usan, ni otros png (`dol_yisang.png`). `SD_Skill_<num>1<hoja>`, el Awakening; `<num>2<hoja>`, la Corrosion. De cada skill, el juego (nombre + hash) más nuevo; las piezas que el juego le añadió luego (`SD_Skill_2080111_Add`, Snagharpoon) son otro juego y también se bajan |
| `sound/sfx/` | Audio/Sound Effects/Sinners/`<Pecador>`/EGO/`<E.G.O>`/ | Todos los `.wav` |
| `sound/voice/` | Audio/Voicefiles/Sinners/`<Pecador>`/EGO/`<E.G.O>`/ | Todos los `.wav` (Crow's Eye View trae también `battle_upgrade_10101_*`) |
| `images/sprites/Corrosion_<E.G.O>_<Pecador>_Idle_Animation.gif` | wiki.gg, `https://limbuscompany.wiki.gg/images/<archivo>` | Solo si tiene Corrosion (hay arte `erosion_*`). Espacios a `_`. No va al zip |

Tiene Corrosion si en su arte hay `erosion_*`; los ZAYIN base no (Crow's Eye View, Representation Emitter), y entonces no se baja su arte ni el gif. La wiki se baja con `curl` **tal cual, sin cabecera de navegador** (con `-A "Mozilla/..."` da 403). Nunca la de Fandom.

## La herramienta: `import_ego.py`

`<skill>` es la carpeta de esta skill (la de este `SKILL.md`: el "Base directory" que sale al cargarla), esté en el repo (`Claude/Skills/...`) o instalada desde su zip (`~/.claude/skills/...`). El script busca el repo subiendo desde la carpeta actual, así que se ejecuta **desde la raíz del repo** (o con su ruta en la variable `BINGUS_REPO`).

Necesita un Python 3 con `numpy`, `scipy` y Pillow, y `curl` (viene con Windows 10/11). Antes del primer paso, `python -c "import numpy, scipy, PIL"`; si falla, prueba con `py` o `python3` (en un PC puede haber varios Python y solo uno con ellos), y si ninguno los tiene, pídele al usuario que los instale (`python -m pip install numpy scipy pillow`). Con `-I` y 2-3 minutos como mucho por paso:

```
python -I "<skill>/import_ego.py" new     "EGO/Faust/Representation Emitter" --grade ZAYIN
python -I "<skill>/import_ego.py" fetch   "EGO/Faust/Representation Emitter" --dl "<scratchpad>/<ego>_dl"
python -I "<skill>/import_ego.py" index   "EGO/Faust/Representation Emitter"
python -I "<skill>/import_ego.py" sprites "EGO/Faust/Representation Emitter" --sheets "<scratchpad>/<ego>_sheets"
python -I "<skill>/import_ego.py" zip     "EGO/Faust/Representation Emitter"
```

El pecador y el nombre salen de la ruta (`EGO/<Pecador>/<E.G.O>`); `--sinner`/`--name` si en Drive se llaman distinto (las carpetas se comparan sin mayúsculas ni signos: `Crow's` = `Crow’s`; pero las vocales con tilde se quitan, no se igualan: la carpeta es `EGO/Outis/To Pathos Mathos` y el `fetch`, con `--name "To Páthos Máthos"`). Los ZAYIN base de los 12 ya están hechos (ver `EGO.md#animaciones`).

- **`new`**: si no hay `EGO.xml`, copia `EGO/TEMPLATE/EGO.xml` con `sinner`, `grade` y el nombre en su `<Awakening>` (como "Nuevo…" del editor, `EgoDocument.CreateFromTemplate`), el `schemaLocation` un nivel más abajo y `animation-id="s1c1"` en la moneda. Deja un `sprites.json` mínimo (`atlases`, `sprites`, `sfx`, `voice` y `animations`, cada uno con su `comment`), que el Animator ya abre. No rellena stats. Si ya existe, no toca nada.
- **`fetch`**: baja a `--dl` (una carpeta nueva del scratchpad), comprueba la cabecera (PNG, WAV, GIF) y copia al E.G.O. Al final, lo descartado (versiones viejas, otros png de sprites), si no tiene Corrosion y lo que no ha encontrado. Si Drive o la wiki bloquean (403, 429), **no hay que saltárselo**: para y pásale al usuario los enlaces y dónde guardarlos.
- **`index`**: `atlases` por el número de skill del atlas (`SD_Skill_2010311` → `s1`, el Awakening; `SD_Skill_2010321` → `s2`, la Corrosion; las otras hojas de la misma skill, `s1b`, `s1c`…; la hoja `_Add`, `s1add`); `sfx` con nombres limpios, sin las palabras del pecador ni sus apodos (`SINNER_NICKS` de `import_identity.py`: `Isang`, `Donki`, `DQ`, `Hongru`…; si sale uno nuevo, se añade) (`133_yisang_base_ego-1_a_v1` → `ego_1`, `Isang_EGO_Default1` → `default_1`, `SFX_StoneYi_Chim` → `stone_chim`, `Faust_Normal_EGO_SFX` → `normal`; si se queda vacío, `sfx`: `Ryoshu_SFX` → `sfx`; si empieza por cifra, `sfx_`: `20103` → `sfx_20103`, `02FS` → `sfx_02fs`) y `voice` (`battle_awaken_*` → `awaken`, también con guiones, `battle-awaken-20801-2`; `battle_erosion_*` → `erosion`; si hay varias, `_1`, `_2`…; las demás, limpias como los sfx y con `voice_` si empiezan por cifra: `DQ_EGO_AFTER7` → `after_7`, `10EGO-000` → `voice_10ego_000`). Sin `dead`. Si `animations` está vacío, deja un comentario con la convención (`s1c<n>`, `s2c<n>`). Deja `idle` y `sprites` como estén.
- **`sprites`**: todas las piezas de los atlas, como las corta el cliente (alfa > 6, engordado 3 px, componentes de 4 vecinos, de 2000 píxeles opacos o más), con su `rect`, ordenadas de arriba abajo: `<atlas>_<n>`. Sin poses comunes (no hay `_Sprite` de la wiki). Si se vuelve a ejecutar, **junta** con lo que había: las entradas que ya estaban se quedan tal cual (nombres, `pivot`, `rotated`, `facing`, las partidas o mapeadas a mano y el `comment`) y solo añade, detrás, las piezas que no cubre ninguna; de las que ya no valen (su atlas no está o el `rect` se sale) avisa, sin quitarlas (ver la skill `import-identity`). Deja una hoja de contacto por atlas en `--sheets` (las piezas ya derechas; `R` = rotated, `L`/`R` = facing).
- **`zip`**: `Python/pack_ego.py`, que mete todo menos los `.gif`, `animator.json` y los `.json` de `images/` (el que deja `gif2sheet`).

## Proceso

1. `new` (con el grado: la wiki.gg lo dice; los base de cada pecador son ZAYIN) y `fetch`. Si falta algo, mira la carpeta a mano (`embeddedfolderview`) por si el nombre cambia.
2. `index` y `sprites`.
3. **Revisar las piezas a ojo** con las hojas de contacto:
   - Las que salen boca abajo llevan `rotated: true` (en Representation Emitter, casi la mitad). Ponlo y vuelve a ejecutar `sprites` para ver las hojas ya derechas.
   - `facing`: hacia dónde mira una vez derecha (la cara; los primeros planos de cara de los cut-in suelen mirar a la izquierda). Si no está claro, provisional, y dilo en el `comment`.
   - Las motas: en un E.G.O casi siempre son piezas de verdad (líneas de velocidad, trazos de polvo, esquirlas, chispas, humo; en los 10 ZAYIN base lo eran todas). Míralas antes de descartarlas: con el mismo corte (`pieces` de `import_identity.py`) pero desde 100 píxeles salen con su `rect`. Se mapean a mano (`s1_lines_<n>`, `s1b_smoke_<n>`, `s2_rock_<n>`…) y se apuntan en el `comment`. Un nuevo `sprites` las conserva (junta, no pisa).
   - Escribe todo en el `comment` de `sprites` (ver el de Wishing Cairn o Representation Emitter): qué atlas es cada uno, qué pieza es qué, motas, repetidas, `facing` provisional.
4. **El idle de la Corrosion** (solo si la tiene), con `Python/gif2sheet.py` desde la carpeta del E.G.O:
   `python -I ../../../Python/gif2sheet.py images/sprites/Corrosion_<E.G.O>_<Pecador>_Idle_Animation.gif -o images/sprites/corrosion_idle.png --scale <s> --pivot <x> <y> --into sprites.json --key idle`
   La escala, comparando un fotograma con la pose de pie de la Corrosion en `s2` (en Wishing Cairn el gif encaja con `s2_20` sin espejar, a 1,196×: `--scale 0.84`); los pies, entre las dos piernas (`--pivot`: Wishing Cairn, `330 708`). Si el gif es grande, `--max-size 6000`. Pinta un fotograma con los pies al lado de la pose para ver que cuadran.
5. **`animation-id`** en `EGO.xml`: `s1c<n>` en las monedas del Awakening y `s2c<n>` en las de la Corrosion (`new` ya pone `s1c1` en la de la plantilla). Si el usuario ya ha puesto las monedas, que cada una tenga el suyo.
6. `zip`, y comprueba que todas las rutas del `sprites.json` están en el zip.
7. Comprueba:
   - el Animator: desde `Bingus.Animator`, `SpriteSet("<E.G.O>").load(json)` de `bingus_anim/sprites.py`, sin `errors`;
   - `dotnet run --project Bingus.Tests`: `EgoTests.Sprites` mira todos los E.G.O (su `sprites.json`, que atlas, idle y sonidos están en el zip y los `animation-id`). Si el E.G.O es del primer E.G.O de un pecador, mira que ningún test use a ese pecador como "sin E.G.O";
   - el editor: `Bingus.Identity.Editor/bin/Debug/net10.0/Bingus.Identity.Editor.exe --selftest` (sin nombre: con uno, solo busca IDs).
8. Apunta el E.G.O en "Hechos" de `EGO.md#animaciones`.
