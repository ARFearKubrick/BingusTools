"""
import_identity: trae los archivos de una ID desde la carpeta pública de Drive "Limbus Company - Organized Assets"
y de la wiki.gg, los indexa en su sprites.json y rehace el zip. Ver SKILL.md, al lado.

    python -I import_identity.py fetch   "Identities/Ishmael/LCB Sinner Ishmael" --sinner Ishmael --num 10801 --wiki LCB_Sinner_Ishmael --dl <scratchpad>/dl
    python -I import_identity.py index   "Identities/Ishmael/LCB Sinner Ishmael"
    python -I import_identity.py sprites "Identities/Ishmael/LCB Sinner Ishmael" --wiki-dir <scratchpad>/dl/wiki --sheets <scratchpad>/sheets
    python -I import_identity.py zip     "Identities/Ishmael/LCB Sinner Ishmael"

index, sprites y zip valen también para un E.G.O (una carpeta con EGO.xml, como "EGO/Yi Sang/Wishing Cairn"): sus atlas
son s1 (Awakening) y s2 (Corrosion), sin dead ni poses comunes, y el zip lo hace Python/pack_ego.py. Su fetch (y crearlo
desde la plantilla) está en import_ego.py, de la skill import-ego.

Se ejecuta desde la raíz del repo de Bingus (o desde dentro): de ahí saca Python/gif2sheet.py y Python/pack_ego.py, esté
donde esté instalada la skill. Si no, la ruta del repo en la variable BINGUS_REPO.

Requiere numpy, scipy y Pillow, y curl.
"""
from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import os
import re
import shutil
import subprocess
import sys
import urllib.request
import zipfile
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage

REPO_MARKS = ("forbidden.md", "Python/gif2sheet.py", "Python/pack_ego.py", "EGO/TEMPLATE/EGO.xml")


def find_repo() -> Path:
    """La raíz del repo: BINGUS_REPO, o subiendo desde la carpeta actual o desde este script. La skill puede estar
    instalada fuera del repo (~/.claude/skills, de un zip), así que no vale suponer dónde está el script."""
    starts = [Path(os.environ["BINGUS_REPO"])] if os.environ.get("BINGUS_REPO") else []
    starts += [Path.cwd(), Path(__file__).resolve().parent]
    for start in starts:
        start = start.resolve()
        for d in (start, *start.parents):
            if all((d / m).exists() for m in REPO_MARKS):
                return d
    sys.exit("No encuentro el repo de Bingus (con " + ", ".join(REPO_MARKS) + "): ejecútalo desde su raíz "
             "o pon su ruta en la variable BINGUS_REPO.")


REPO = find_repo()
sys.path.insert(0, str(REPO / "Python"))
from gif2sheet import to_json  # noqa: E402  (mismo formato de sprites.json que gif2sheet)

ROOT = "1Nk9WWMxEcovs5Ewku5ICT1PbfByNcV_z"      # Limbus Company - Organized Assets
WIKI = "https://limbuscompany.wiki.gg/images/"

# Voces de la partida (ver animations.md, "voice"): prefijo del archivo -> nombre en voice
VOICE_GAME = {"formation": "selected", "battle_select": "select", "battle_endcommand": "turnStart",
              "battle_break": "hit", "battle_enemy_break": "stagger", "battle_kill": "kill"}
# Voces que se bajan: las de la partida, las de las skills y battleentry (sin usar)
VOICE_PREFIXES = list(VOICE_GAME) + ["battle_s2", "battle_s3", "battleentry"]

# Poses comunes y su _Sprite de la wiki
COMMON_POSES = {"guard": "Guard", "evade": "Evade", "hurt": "Hurt", "move": "Moving", "stand": "Idle"}

# actors.ts SOLID_ALPHA y GROW, como isolate en Bingus.Animator/bingus_anim/sprites.py
SOLID_ALPHA = 6
GROW = 3
MIN_PIECE = 2000        # píxeles opacos para contar como pieza (menos: motas sueltas de una vecina)


#region Drive

def parse_date(text: str) -> dt.date:
    """Fecha de la vista pública: '3/5/23', 'Mar 11' (de este año) o una hora (hoy)."""
    text = text.strip()
    today = dt.date.today()
    if m := re.fullmatch(r"(\d+)/(\d+)/(\d+)", text):
        mo, d, y = map(int, m.groups())
        return dt.date(2000 + y if y < 100 else y, mo, d)
    try:
        d = dt.datetime.strptime(f"{text} {today.year}", "%b %d %Y").date()
        return d if d <= today else d.replace(year=today.year - 1)
    except ValueError:
        return today


def ls(folder: str) -> list[dict]:
    """Lo que hay en una carpeta pública de Drive: carpetas y archivos, con su fecha."""
    page = urllib.request.urlopen("https://drive.google.com/embeddedfolderview?id=" + folder, timeout=60)
    text = page.read().decode("utf-8", "replace")
    out = []
    for m in re.finditer(r'href="https://drive\.google\.com/(drive/folders/|file/d/)([\w-]+)[^"]*"[^>]*>.*?'
                         r'flip-entry-title">([^<]+)<.*?flip-entry-last-modified"><div>([^<]*)<', text, re.S):
        out.append({"dir": m.group(1).startswith("drive"), "id": m.group(2),
                    "name": html.unescape(m.group(3)), "date": parse_date(m.group(4))})
    return out


def cd(folder: str, *names: str) -> str | None:
    """Baja por las subcarpetas con esos nombres (sin distinguir mayúsculas). None si falta alguna."""
    for name in names:
        hit = [e for e in ls(folder) if e["dir"] and e["name"].lower() == name.lower()]
        if not hit:
            return None
        folder = hit[0]["id"]
    return folder


MAGIC = {".png": [b"\x89PNG"], ".gif": [b"GIF8"], ".wav": [b"RIFF"]}


def check_magic(path: Path) -> None:
    head = path.read_bytes()[:4]
    if not any(head.startswith(m) for m in MAGIC.get(path.suffix.lower(), [head])):
        raise RuntimeError(f"{path.name}: no es un {path.suffix} ({head!r})")


def download(file_id: str, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    for url in ("https://drive.google.com/uc?export=download&id=" + file_id,
                "https://drive.usercontent.google.com/download?export=download&confirm=t&id=" + file_id):
        data = urllib.request.urlopen(url, timeout=120).read()
        if not data.lstrip()[:15].lower().startswith((b"<!doctype", b"<html")):
            dest.write_bytes(data)
            check_magic(dest)
            return
    raise RuntimeError(f"Drive no deja bajar {dest.name} ({file_id})")


def wiki_download(name: str, dest: Path) -> bool:
    """Un archivo de la wiki.gg con curl tal cual (con cabecera de navegador da 403). False si no está."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    r = subprocess.run(["curl", "-s", "-o", str(dest), "-w", "%{http_code}", WIKI + name],
                       capture_output=True, text=True, timeout=120)
    if r.stdout.strip() != "200":
        dest.unlink(missing_ok=True)
        if r.stdout.strip() in ("403", "429"):
            print(f"  ! la wiki bloquea {WIKI + name} ({r.stdout.strip()}): bájalo a mano")
        return False
    check_magic(dest)
    return True

#endregion


#region Versiones

ATLAS_RE = re.compile(r"sactx-(\d+)-(\d+)x(\d+)-[^-]+-(.+)-([0-9a-f]{8})\.png$", re.I)
SKILL_ROLE = re.compile(r"^(Base_Common|S\d+)$", re.I)


def newest(files: list[dict]) -> tuple[dict | None, list[dict]]:
    """El más reciente y los descartados."""
    if not files:
        return None, []
    files = sorted(files, key=lambda f: f["date"], reverse=True)
    return files[0], files[1:]


def pick_atlases(files: list[dict]) -> tuple[list[dict], list[dict]]:
    """
    Los atlas que valen: se agrupan por juego (nombre + hash, con todas sus hojas sactx-N) y por papel (Base_Common,
    S1, S2...; los demás, atlas del personaje entero). De cada papel, el juego más nuevo. Si el atlas entero más nuevo
    es posterior a los de skills, es un rediseño y los sustituye a todos (Heathcliff, cp6).
    """
    sets: dict[tuple[str, str], list[dict]] = {}
    for f in files:
        if m := ATLAS_RE.match(f["name"]):
            sets.setdefault((m.group(4), m.group(5)), []).append(f)
    date = {k: max(f["date"] for f in v) for k, v in sets.items()}
    by_role: dict[str, list[tuple[str, str]]] = {}
    for k in sets:
        by_role.setdefault(k[0].lower() if SKILL_ROLE.match(k[0]) else "*whole", []).append(k)
    keep = {r: max(ks, key=date.get) for r, ks in by_role.items()}
    if "*whole" in keep:
        whole = date[keep["*whole"]]
        if all(date[k] <= whole for r, k in keep.items() if r != "*whole"):
            keep = {"*whole": keep["*whole"]}
        else:
            keep.pop("*whole")
    chosen = [f for k in keep.values() for f in sets[k]]
    return chosen, [f for f in files if f not in chosen]

#endregion


#region fetch

def cmd_fetch(a) -> None:
    ident = Path(a.identity)
    dl = Path(a.dl)
    num, sinner, idf = a.num, a.sinner, a.id_folder
    report: list[str] = []
    missing: list[str] = []
    copied: list[tuple[Path, Path]] = []

    def get(entry: dict, rel: str) -> None:
        tmp = dl / "drive" / rel
        download(entry["id"], tmp)
        copied.append((tmp, ident / rel))

    def discarded(what: str, rest: list[dict]) -> None:
        for f in rest:
            report.append(f"  descartado ({what}): {f['name']} ({f['date']})")

    images = cd(ROOT, "Images")
    audio = cd(ROOT, "Audio")

    # Arte: profile, portrait, thumb
    art = cd(images, "Identity & EGO Art", sinner, "Identities", idf)
    art_files = ls(art) if art else []
    for dest, suffix in [("images/profile.png", "_gacksung_profile.png"), ("images/portrait.png", "_normal_info.png"),
                         ("images/thumb.png", "_normal.png")]:
        best, rest = newest([f for f in art_files if not f["dir"] and f["name"] == f"{num}{suffix}"])
        if best:
            get(best, dest)
            discarded(dest, rest)
        else:
            missing.append(f"Identity & EGO Art/{sinner}/Identities/{idf}/{num}{suffix}")

    # Iconos de las skills: <num>01..03 y la de guardia <num>04 (la _4, de uptie 4, si la hay)
    icons = cd(images, "Icons", "Skills", "Sinners", sinner, idf)
    icon_files = [f for f in (ls(icons) if icons else []) if not f["dir"]]
    for n in range(1, 5):
        base = f"{num}0{n}"
        cands = [f for f in icon_files if re.fullmatch(rf"{base}(_\d+)?\.png", f["name"])]
        pref = [f for f in cands if f["name"] == f"{base}_4.png"] or [f for f in cands if f["name"] == f"{base}.png"] or cands
        best, rest = newest(pref)
        if best:
            get(best, f"images/skills/{best['name']}")
            discarded("icono", [f for f in cands if f is not best])
        else:
            missing.append(f"Icons/Skills/Sinners/{sinner}/{idf}/{base}.png")

    # Sprites: dead (en la carpeta del pecador) y los atlas (solo el primer nivel de la carpeta de la ID)
    spr = cd(images, "Sprites", "Sinners", sinner)
    spr_files = ls(spr) if spr else []
    best, rest = newest([f for f in spr_files if not f["dir"] and re.match(r"dead\b.*\.png$", f["name"], re.I)])
    if best:
        get(best, f"images/sprites/{best['name']}")
        discarded("dead", rest)
    else:
        missing.append(f"Sprites/Sinners/{sinner}/dead*.png")
    atl = cd(spr, "Identities", idf) if spr else None
    atl_files = [f for f in (ls(atl) if atl else []) if not f["dir"] and ATLAS_RE.match(f["name"])]
    chosen, rest = pick_atlases(atl_files)
    for f in chosen:
        get(f, f"images/sprites/{f['name']}")
    discarded("atlas", rest)
    if not chosen:
        missing.append(f"Sprites/Sinners/{sinner}/Identities/{idf}/sactx-*.png")

    # Efectos: <pecador>_N_M.wav (no los NNN_<pecador>_base_skillN_a_v1)
    sfx = cd(audio, "Sound Effects", "Sinners", sinner, "Identities", idf)
    sfx_files = [f for f in (ls(sfx) if sfx else []) if not f["dir"] and f["name"].lower().endswith(".wav")]
    for f in sfx_files:
        if re.match(r"\d{3}_", f["name"]):
            report.append(f"  sin bajar (sfx): {f['name']}")
        else:
            get(f, f"sound/sfx/{f['name']}")
    if not sfx_files:
        missing.append(f"Sound Effects/Sinners/{sinner}/Identities/{idf}/*.wav")

    # Voces: las de la partida, las de las skills y battleentry, de esta ID
    voice = cd(audio, "Voicefiles", "Sinners", sinner, "Identities", idf)
    voice_files = [f for f in (ls(voice) if voice else []) if not f["dir"]]
    for prefix in VOICE_PREFIXES:
        hits = [f for f in voice_files if re.fullmatch(rf"{prefix}_{num}_\d+(_\d+)?\.wav", f["name"])]
        for f in hits:
            get(f, f"sound/voice/{f['name']}")
        if not hits:
            missing.append(f"Voicefiles/Sinners/{sinner}/Identities/{idf}/{prefix}_{num}_*.wav")

    # Wiki: el gif del idle y los de las skills (a la ID), los _Sprite de las poses comunes (solo al scratchpad)
    for name in [f"{a.wiki}_Idle_Animation.gif"] + [f"{a.wiki}_Skill_{n}.gif" for n in (1, 2, 3)]:
        tmp = dl / "wiki" / name
        if wiki_download(name, tmp):
            copied.append((tmp, ident / "images/sprites" / name))
        else:
            missing.append(WIKI + name)
    for pose in COMMON_POSES.values():
        name = f"{a.wiki}_{pose}_Sprite.png"
        if not wiki_download(name, dl / "wiki" / name):
            missing.append(WIKI + name)

    for src, dst in copied:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        print("  +", dst.relative_to(ident).as_posix())
    print("\n".join(report))
    if missing:
        print("No encontrado:\n  " + "\n  ".join(missing))

#endregion


#region index

def atlas_short_names(paths: list[str], current: dict | None = None, root: Path | None = None) -> dict[str, str]:
    """
    Nombre corto de cada atlas: common, s1, s2... (la hoja sactx-1 de S3, s3b; la sactx-2, s3c) o, si es un atlas del
    personaje entero, a0, a1... por hoja. Si dos juegos (otro hash) dan el mismo nombre, uno solo (pick_short_names).
    """
    out: dict[str, list[str]] = {}
    for p in sorted(paths, key=lambda p: (ATLAS_RE.search(p).group(4).lower(), int(ATLAS_RE.search(p).group(1)))):
        m = ATLAS_RE.search(p)
        sheet, role = int(m.group(1)), m.group(4)
        if SKILL_ROLE.match(role):
            base = "common" if role.lower() == "base_common" else role.lower()
            out.setdefault(base + ("" if sheet == 0 else chr(ord("a") + sheet)), []).append(p)
        else:
            out.setdefault(f"a{sheet}", []).append(p)
    out = pick_short_names(out, current, root)
    order = lambda k: (k != "common", k)
    return {k: out[k] for k in sorted(out, key=order)}


def pick_short_names(names: dict[str, list[str]], current: dict | None, root: Path | None) -> dict[str, str]:
    """
    Un atlas por nombre corto. Si hay varios (dos juegos de atlas, de otro hash, para el mismo papel y la misma hoja),
    el del juego que ya está en los `atlases` de sprites.json (`current`) o, si no, el del juego más nuevo (fecha del
    archivo, en `root`), con un aviso: los otros no se pisan sin decirlo.
    """
    used = set((current or {}).values())
    game = lambda p: (ATLAS_RE.search(p).group(4).lower(), ATLAS_RE.search(p).group(5).lower())
    games: dict[tuple[str, str], list[str]] = {}
    for p in (p for ps in names.values() for p in ps):
        games.setdefault(game(p), []).append(p)
    mtime = lambda p: (root / p).stat().st_mtime if root and (root / p).exists() else 0.0
    rank = lambda p: (any(f in used for f in games[game(p)]), max(mtime(f) for f in games[game(p)]), p)
    out = {}
    for short, ps in names.items():
        out[short] = max(ps, key=rank)
        if len(ps) > 1:
            why = "el que ya estaba en atlases" if rank(out[short])[0] else "el más nuevo"
            print(f"  aviso: {short}: {len(ps)} atlas con ese nombre ({', '.join(Path(p).name for p in ps)}); "
                  f"se queda {Path(out[short]).name} ({why})")
    return out


def sfx_key(stem: str) -> str | None:
    """ishmael_3_2.wav -> s3_2; honglu_3_2-1.wav -> s3_2_1."""
    m = re.fullmatch(r"[a-z]+_(\d+)_(\d+)(?:-(\d+))?", stem, re.I)
    return "s" + "_".join(g for g in m.groups() if g) if m else None


def is_ego(folder: Path) -> bool:
    """Un paquete de E.G.O (EGO/<pecador>/<E.G.O>/, con EGO.xml) en vez de una ID."""
    return (folder / "EGO.xml").exists()


def read_sprites(folder: Path) -> dict:
    """Su sprites.json ({} si no existe o está vacío, como uno recién creado)."""
    path = folder / "sprites.json"
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    return json.loads(text) if text.strip() else {}


EGO_ATLAS = re.compile(r"SD_Skill_\d{5}(\d)\d(_Add)?$", re.I)


def ego_atlas_names(paths: list[str], current: dict | None = None, root: Path | None = None) -> dict[str, str]:
    """
    Atlas de un E.G.O: SD_Skill_<n.º del E.G.O><skill><hoja>, con skill 1 el Awakening (s1) y 2 la Corrosion (s2).
    Una segunda hoja de la misma skill, s1b. Las piezas que el juego añadió luego (SD_Skill_2080111_Add), s1add. Si dos
    juegos dan el mismo nombre, uno solo (pick_short_names).
    """
    out: dict[str, list[str]] = {}
    for p in sorted(paths):
        m = EGO_ATLAS.search(ATLAS_RE.search(p).group(4))
        sheet = int(ATLAS_RE.search(p).group(1))
        out.setdefault(f"s{m.group(1)}" + ("add" if m.group(2) else "") + ("" if sheet == 0 else chr(ord("a") + sheet)),
                       []).append(p)
    return dict(sorted(pick_short_names(out, current, root).items()))


def ego_sound_key(stem: str, sinner: str = "", prefix: str = "sfx") -> str:
    """
    Nombre de un sonido de E.G.O: 133_yisang_base_ego-1_a_v1 -> ego_1; Isang_EGO_Default1 -> default_1;
    YiSang_Knife_out -> knife_out; SFX_StoneYi_Chim -> stone_chim; 20103 -> sfx_20103; 02FS -> sfx_02fs;
    Faust_Normal_EGO_SFX -> normal; Donki_EGO_Default1 -> default_1; DQ_EGO_AFTER7 -> after_7; Ryoshu_SFX -> sfx.
    Quita las palabras del pecador (el nombre de su carpeta) y sus apodos en los archivos (SINNER_NICKS). Si empieza
    por cifra o se queda vacío, con <prefix> (en las voces, voice: 10EGO-000 -> voice_10ego_000).
    """
    if m := re.fullmatch(r"\d+_[a-z]+_base_ego-(\d+)_a_v\d+", stem, re.I):
        return f"ego_{m.group(1)}"
    drop = {"sfx", "ego"} | SINNER_NICKS | {w for w in re.split(r"[^a-z0-9]+", sinner.lower()) if w}
    words = [w for w in re.split(r"[^a-z0-9]+", re.sub(r"([a-z])([A-Z])", r"\1_\2", stem).lower()) if w]
    key = re.sub(r"([a-z])(\d+)$", r"\1_\2", "_".join(w for w in words if w not in drop)) or prefix
    return f"{prefix}_{key}" if key[:1].isdigit() else key


# Cómo se llama a cada pecador en los nombres de sus sonidos, además de su nombre (Isang_EGO_Default1, Donki_EGO_...)
SINNER_NICKS = {"isang", "donki", "dq", "honglu", "hongru"}

# El comment de `animations` de un E.G.O sin animar (lo deja index, y el sprites.json que crea import_ego.py new)
EGO_ANIMATIONS_COMMENT = ("Monedas: s1c<n> las del Awakening y s2c<n> las de la Corrosion (animation-id de cada <Coin> "
                          "de EGO.xml). Poses opcionales (hurt, guard, evade, move, stand, attack, clash): las de la "
                          "unidad corroída; si falta una, la de su ID. Ver EGO.md. Todavía sin animar.")


def cmd_index_ego(ident: Path, data: dict) -> None:
    """index de un E.G.O: atlases (s1, s2), sfx y voice; sin dead."""
    path = ident / "sprites.json"
    rel = lambda p: p.relative_to(ident).as_posix()
    atlases = ego_atlas_names([rel(p) for p in sorted((ident / "images/sprites").glob("sactx-*.png"))],
                              data.get("atlases"), ident)

    def unique(d: dict, k: str) -> str:
        n, key = 2, k
        while key in d:
            key, n = f"{k}_{n}", n + 1
        return key

    sfx: dict = {"comment": "Sonidos con nombre (ver animations.md). Solo indexados: aún no los usa ninguna moneda."}
    for p in sorted((ident / "sound/sfx").glob("*.wav")):
        sfx[unique(sfx, ego_sound_key(p.stem, ident.resolve().parent.name))] = rel(p)

    # battle_awaken_20101_1 -> awaken; battle_erosion_20103_1 -> erosion; si hay varias de una, upgrade_1, upgrade_2...
    # Las demás, con el nombre limpio de los sfx (DQ_EGO_AFTER7 -> after_7)
    groups: dict[str, list[Path]] = {}
    for p in sorted((ident / "sound/voice").glob("*.wav"), key=lambda p: p.stem.replace("-", "_")):
        m = re.fullmatch(r"battle[_-]([a-z]+)[_-]\d+[_-]\d+", p.stem)  # también battle-awaken-20801-2
        groups.setdefault(m.group(1) if m else ego_sound_key(p.stem, ident.resolve().parent.name, "voice"), []).append(p)
    known = {"awaken": "awaken: al usar el Awakening", "erosion": "erosion: al usar la Corrosion"}
    voice: dict = {"comment": "Voces con nombre, por el canal de voz (ver animations.md). "
                              + "".join(f"{known[w]}. " for w in groups if w in known)
                              + "Solo indexadas: aún no las usa ninguna moneda."}
    for word, files in groups.items():
        for i, p in enumerate(files, start=1):
            voice[word if len(files) == 1 else f"{word}_{i}"] = rel(p)

    # Orden de claves: idle (el de la Corrosion), atlases, sprites, sfx, voice, animations
    out = {}
    if "idle" in data:
        out["idle"] = data["idle"]
    out["atlases"] = atlases
    out["sprites"] = data.get("sprites", {})
    out["sfx"] = sfx
    out["voice"] = voice
    out["animations"] = data.get("animations") or {"comment": EGO_ANIMATIONS_COMMENT}
    for k, v in data.items():
        out.setdefault(k, v)
    path.write_text(to_json(out) + "\n", encoding="utf-8")
    print(f"{path}: {len(atlases)} atlas, {len(sfx) - 1} sfx, {len(voice) - 1} voces")


def cmd_index(a) -> None:
    ident = Path(a.identity)
    if is_ego(ident):
        return cmd_index_ego(ident, read_sprites(ident))
    path = ident / "sprites.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    rel = lambda p: p.relative_to(ident).as_posix()

    deads = sorted((ident / "images/sprites").glob("dead*.png"))
    atlases = atlas_short_names([rel(p) for p in sorted((ident / "images/sprites").glob("sactx-*.png"))],
                                data.get("atlases"), ident)

    sfx: dict = {"comment": "Sonidos con nombre (ver animations.md). Solo indexados: aún no los usa ninguna moneda ni grupo."}
    for p in sorted((ident / "sound/sfx").glob("*.wav")):
        if k := sfx_key(p.stem):
            sfx[k] = rel(p)
    firsts = [sfx[k] for n in (1, 2) for k in sorted(k for k in sfx if k.startswith(f"s{n}_"))[:1]]
    if firsts:
        sfx["clash_sfx"] = firsts

    voice: dict = {}
    files = sorted((ident / "sound/voice").glob("*.wav"))
    unused = []
    for prefix, key in VOICE_GAME.items():
        for p in files:
            if re.fullmatch(rf"{prefix}_\d+_\d+", p.stem):
                voice[key] = rel(p)
    for s in ("s2", "s3"):
        hits = [p for p in files if p.stem.startswith(f"battle_{s}_")]
        if len(hits) == 1:
            voice[s] = rel(hits[0])
        for i, p in enumerate(hits if len(hits) > 1 else [], start=1):
            voice[f"{s}_{i}"] = rel(p)
    unused = [p.stem for p in files if rel(p) not in voice.values()]
    skill = [k for k in voice if k.startswith(("s2", "s3"))]
    voice = {"comment": "Voces con nombre, por el canal de voz (ver animations.md). Las de la partida ya están puestas; "
                        f"las de las skills ({', '.join(skill)}), solo indexadas: aún no las usa ninguna moneda."
                        + (f" {', '.join(unused)}, sin usar." if unused else ""), **voice}

    # Mismo orden de claves que las otras IDs: dead, idle, atlases, sprites, sfx, voice, animations
    out = {}
    if deads:
        out["dead"] = rel(deads[-1])
    out["idle"] = data.get("idle", {})
    out["atlases"] = atlases
    out["sprites"] = data.get("sprites", {})
    out["sfx"] = sfx
    out["voice"] = voice
    for k, v in data.items():
        out.setdefault(k, v)
    path.write_text(to_json(out) + "\n", encoding="utf-8")
    print(f"{path}: dead, {len(atlases)} atlas, {len(sfx) - 1} sfx, {len(voice) - 1} voces")

#endregion


#region sprites

def pieces(img: np.ndarray) -> tuple[list[dict], list[int]]:
    """Las piezas de un atlas, como el cliente: lo opaco engordado GROW px, en componentes de 4 vecinos."""
    solid = img[..., 3] > SOLID_ALPHA
    grown = ndimage.binary_dilation(solid, structure=np.ones((2 * GROW + 1, 2 * GROW + 1), bool))
    label, n = ndimage.label(grown)
    counts = np.bincount(label.ravel(), weights=solid.ravel(), minlength=n + 1)
    out, motes = [], []
    for i, sl in enumerate(ndimage.find_objects(label), start=1):
        if counts[i] < MIN_PIECE:
            if counts[i] >= 100:
                motes.append(int(counts[i]))
            continue
        ys, xs = np.nonzero((label[sl] == i) & solid[sl])
        x0, y0 = sl[1].start + xs.min(), sl[0].start + ys.min()
        rect = [int(x0), int(y0), int(xs.max() - xs.min() + 1), int(ys.max() - ys.min() + 1)]
        crop = img[rect[1]:rect[1] + rect[3], rect[0]:rect[0] + rect[2]].copy()
        crop[label[rect[1]:rect[1] + rect[3], rect[0]:rect[0] + rect[2]] != i] = 0
        out.append({"rect": rect, "image": crop, "count": int(counts[i])})
    out.sort(key=lambda p: (p["rect"][1], p["rect"][0]))
    return out, sorted(motes, reverse=True)


def trim(img: np.ndarray) -> np.ndarray:
    ys, xs = np.nonzero(img[..., 3] > SOLID_ALPHA)
    return img[ys.min():ys.max() + 1, xs.min():xs.max() + 1] if len(ys) else img


def match_score(piece: np.ndarray, ref: np.ndarray) -> float:
    """Diferencia media (0-1) entre la pieza reescalada al tamaño de ref y ref, con el color premultiplicado."""
    h, w = ref.shape[:2]
    ph, pw = piece.shape[:2]
    if abs(np.log((pw / ph) / (w / h))) > 0.25:
        return 1.0
    p = np.asarray(Image.fromarray(piece).resize((w, h), Image.BILINEAR), np.float32) / 255
    r = ref.astype(np.float32) / 255
    pp = np.concatenate([p[..., :3] * p[..., 3:], p[..., 3:]], -1)
    rr = np.concatenate([r[..., :3] * r[..., 3:], r[..., 3:]], -1)
    return float(np.abs(pp - rr).mean())


def contact_sheet(items: list[tuple[str, np.ndarray]], path: Path, cell: int = 220) -> None:
    """Las piezas ya derechas, en una cuadrícula, con su nombre, sobre gris (para ver hacia dónde miran)."""
    cols = 6
    rows = (len(items) + cols - 1) // cols
    sheet = Image.new("RGBA", (cols * cell, rows * (cell + 16)), (90, 90, 90, 255))
    draw = ImageDraw.Draw(sheet)
    for i, (name, img) in enumerate(items):
        im = Image.fromarray(img)
        im.thumbnail((cell - 8, cell - 8))
        x, y = (i % cols) * cell, (i // cols) * (cell + 16)
        sheet.alpha_composite(im, (x + (cell - im.width) // 2, y + 16 + (cell - im.height) // 2))
        draw.text((x + 4, y + 2), name, fill=(255, 255, 0, 255))
    path.parent.mkdir(parents=True, exist_ok=True)
    sheet.convert("RGB").save(path)


def rect_problem(entry: dict, atlases: dict, images: dict[str, np.ndarray]) -> str | None:
    """Por qué una entrada de `sprites` ya no vale (su atlas no está, su rect se sale o está vacío); None si vale."""
    atlas, rect = entry.get("atlas"), entry.get("rect")
    if atlas not in images:
        return f'su atlas "{atlas}" ya no está' + ("" if atlas in atlases else " en atlases")
    if not (isinstance(rect, list) and len(rect) == 4 and all(isinstance(v, int) for v in rect)):
        return f"rect no es [x, y, ancho, alto]: {rect}"
    x, y, w, h = rect
    H, W = images[atlas].shape[:2]
    if w <= 0 or h <= 0 or x < 0 or y < 0 or x + w > W or y + h > H:
        return f"rect {rect} se sale de {atlas} ({W}x{H})"
    if not (images[atlas][y:y + h, x:x + w, 3] > SOLID_ALPHA).any():
        return f"rect {rect} está vacío en {atlas}"
    return None


def cmd_sprites(a) -> None:
    """
    Junta las piezas de los atlas con lo que ya hay en `sprites`: lo que ya está se queda tal cual (nombre, pivot,
    rotated, facing, las piezas partidas a mano...) y solo se añaden las piezas que no cubre ninguna entrada. Las
    entradas cuyo atlas o rect ya no existen también se quedan, con un aviso.
    """
    ident = Path(a.identity)
    path = ident / "sprites.json"
    data = read_sprites(ident)
    if not data.get("atlases"):
        sys.exit(f"{path}: no tiene atlases. Antes de sprites hay que hacer index.")
    current = data.get("sprites") if isinstance(data.get("sprites"), dict) else {}
    wiki = Path(a.wiki_dir) if a.wiki_dir else None

    images: dict[str, np.ndarray] = {}
    found: list[dict] = []
    notes = []
    for short, rel in data["atlases"].items():
        if not (ident / rel).exists():
            print(f"  aviso: {short}: no está {rel}")
            continue
        img = images[short] = np.asarray(Image.open(ident / rel).convert("RGBA"))
        ps, motes = pieces(img)
        for p in ps:
            p["atlas"] = short
        found += ps
        if motes:
            notes.append(f"{short}: {len(motes)} motas de {min(motes)} a {max(motes)} px")
        print(f"{short}: {len(ps)} piezas" + (f", motas descartadas {motes}" if motes else ""))

    # Lo opaco de cada pieza en su atlas (n.º de pieza + 1; 0, nada)
    owner = {short: np.zeros(img.shape[:2], np.int32) for short, img in images.items()}
    for i, p in enumerate(found):
        x, y, w, h = p["rect"]
        owner[p["atlas"]][y:y + h, x:x + w][p["image"][..., 3] > SOLID_ALPHA] = i + 1
    # Lo que ya está se queda. Cada entrada con un rect que vale cubre la pieza de la que tiene más opaco (así cuentan
    # también las partidas a mano, y no las vecinas que asoman en su rect); si no vale, se queda igual, con un aviso
    covered: set[int] = set()
    kept = 0
    for name, e in current.items():
        if not isinstance(e, dict):
            continue
        kept += 1
        if why := rect_problem(e, data["atlases"], images):
            print(f'  aviso: sprite "{name}": {why}. Se deja como está.')
            continue
        x, y, w, h = e["rect"]
        counts = np.bincount(owner[e["atlas"]][y:y + h, x:x + w].ravel())
        if len(counts) > 1 and counts[1:].any():
            covered.add(int(counts[1:].argmax()))
    new = [i for i in range(len(found)) if i not in covered]

    # Poses comunes que falten: la pieza nueva que más se parece a su _Sprite de la wiki, derecha o girada 180°,
    # espejada o no. El _Sprite mira a la derecha: si casa espejada, la pieza mira a la izquierda
    named: dict[int, tuple[str, bool, bool, float]] = {}
    if wiki:
        for pose, wname in COMMON_POSES.items():
            if pose in current:
                continue
            refs = list(wiki.glob(f"*_{wname}_Sprite.png"))
            if not refs:
                print(f"  sin _Sprite para {pose}")
                continue
            ref = trim(np.asarray(Image.open(refs[0]).convert("RGBA")))
            best = (1.0, -1, False, False)
            for i in new:
                if i in named:
                    continue
                p = found[i]
                for rot in (False, True):
                    im = trim(np.rot90(p["image"], 2) if rot else p["image"])
                    for mirror in (False, True):
                        s = match_score(im[:, ::-1] if mirror else im, ref)
                        if s < best[0]:
                            best = (s, i, rot, mirror)
            s, i, rot, mirror = best
            if i >= 0 and s < a.max_score:
                named[i] = (pose, rot, mirror, s)
                print(f"  {pose:6} = {found[i]['atlas']} {found[i]['rect']}  rotated={rot} espejada={mirror} diff={s:.3f}")
            else:
                print(f"  {pose}: sin pareja clara (mejor diff {s:.3f})")

    # Las nuevas, detrás de las que ya estaban: las comunes por su nombre y el resto <atlas>_<n> (el primer n libre)
    added: dict[str, tuple[int, bool, str]] = {}
    for i, (pose, rot, mirror, s) in sorted(named.items(), key=lambda kv: list(COMMON_POSES).index(kv[1][0])):
        added[pose] = (i, rot, "left" if mirror else "right")
    count: dict[str, int] = {}
    for i in new:
        if i in named:
            continue
        atlas = found[i]["atlas"]
        n = count.get(atlas, 0)
        while f"{atlas}_{n}" in current or f"{atlas}_{n}" in added:
            n += 1
        count[atlas] = n + 1
        added[f"{atlas}_{n}"] = (i, False, "right")

    names = ("<atlas>_<n.º de pieza>, por orden de arriba abajo (s1, el atlas del Awakening; s2, el de la Corrosion)"
             if is_ego(ident) else "las poses comunes por su nombre (emparejadas con los _Sprite de la wiki) y el resto "
             "<atlas>_<n.º de pieza>, por orden de arriba abajo")
    out = {"comment": current.get("comment") or
           "rect = [x, y, ancho, alto] en su atlas. rotated: guardado girado 180°. facing: hacia dónde mira una vez "
           f"derecho; el motor lo espeja según el lado. Nombre: {names}. Están todas las piezas de "
           f"los atlas (componentes con alfa > {SOLID_ALPHA}, engordados {GROW} px, de {MIN_PIECE} píxeles opacos o "
           "más)." + (" Motas descartadas (restos de piezas vecinas): " + "; ".join(notes) + "." if notes else "")
           + " Todavía no las usa ninguna animación."}
    out.update((k, v) for k, v in current.items() if k != "comment")
    sheets: dict[str, list] = {}
    for name, e in out.items():
        if isinstance(e, dict) and not rect_problem(e, data["atlases"], images):
            x, y, w, h = e["rect"]
            crop = images[e["atlas"]][y:y + h, x:x + w]
            upright = np.rot90(crop, 2) if e.get("rotated") else crop
            facing = str(e.get("facing", "right"))
            sheets.setdefault(e["atlas"], []).append((f"{name}{' R' if e.get('rotated') else ''} {facing[0].upper()}",
                                                      upright))
    for name, (i, rot, facing) in added.items():
        p = found[i]
        e = {"atlas": p["atlas"], "rect": p["rect"]}
        if rot:
            e["rotated"] = True
        e["facing"] = facing
        out[name] = e
        upright = np.rot90(p["image"], 2) if rot else p["image"]
        sheets.setdefault(p["atlas"], []).append((f"{name}{' R' if rot else ''} {facing[0].upper()} +", upright))

    data["sprites"] = out
    path.write_text(to_json(data) + "\n", encoding="utf-8")
    print(f"{path}: {kept} sprites que ya estaban, {len(added)} nuevos" + (f": {', '.join(added)}" if added else ""))
    if a.sheets:
        for short, items in sheets.items():
            contact_sheet(items, Path(a.sheets) / f"{short}.png")
        print(f"hojas de contacto en {a.sheets} (R = rotated, L/R = facing, + = nueva)")

#endregion


#region zip

def cmd_zip(a) -> None:
    """El zip de la ID: identity.xml, sprites.json, images/ y sound/, sin los gifs ni idle.json. El de un E.G.O, pack_ego."""
    ident = Path(a.identity).resolve()
    if is_ego(ident):
        import pack_ego
        return pack_ego.pack(ident)
    zpath = ident / f"{ident.name}.zip"
    files = [ident / "identity.xml", ident / "sprites.json"]
    for sub in ("images", "sound"):
        files += sorted(p for p in (ident / sub).rglob("*")
                        if p.is_file() and p.suffix.lower() != ".gif" and p.name != "idle.json")
    tmp = zpath.with_suffix(".zip.tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        for p in files:
            z.write(p, p.relative_to(ident).as_posix())
    tmp.replace(zpath)
    print(f"{zpath}: {len(files)} archivos")

#endregion


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    f = sub.add_parser("fetch", help="baja los archivos de Drive y la wiki a la carpeta de la ID")
    f.add_argument("identity")
    f.add_argument("--sinner", required=True, help="nombre del pecador en Drive (Ishmael, Hong Lu...)")
    f.add_argument("--num", required=True, help="número de la ID (10801)")
    f.add_argument("--id-folder", default="LCB Sinner", help="carpeta de la ID en Drive (por defecto 'LCB Sinner')")
    f.add_argument("--wiki", required=True, help="prefijo de la wiki (LCB_Sinner_Ishmael)")
    f.add_argument("--dl", required=True, help="carpeta nueva del scratchpad para las descargas")
    i = sub.add_parser("index", help="dead, atlases, sfx y voice en sprites.json")
    i.add_argument("identity")
    s = sub.add_parser("sprites", help="las piezas de los atlas que aún no están en sprites (y hojas de contacto)")
    s.add_argument("identity")
    s.add_argument("--wiki-dir", help="carpeta con los _Sprite de la wiki (la wiki/ de --dl)")
    s.add_argument("--sheets", help="carpeta para las hojas de contacto")
    s.add_argument("--max-score", type=float, default=0.12, help="diferencia máxima para emparejar una pose común")
    z = sub.add_parser("zip", help="rehace el zip de la ID")
    z.add_argument("identity")
    a = ap.parse_args()
    {"fetch": cmd_fetch, "index": cmd_index, "sprites": cmd_sprites, "zip": cmd_zip}[a.cmd](a)


if __name__ == "__main__":
    main()
