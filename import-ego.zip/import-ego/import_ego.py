"""
import_ego: crea un E.G.O desde EGO/TEMPLATE, trae sus archivos de la carpeta pública de Drive "Limbus Company -
Organized Assets" y el gif del idle de su Corrosion de la wiki.gg, los indexa en su sprites.json y rehace el zip. Ver
SKILL.md, al lado.

    python -I import_ego.py new     "EGO/Faust/Representation Emitter" --grade ZAYIN
    python -I import_ego.py fetch   "EGO/Faust/Representation Emitter" --dl <scratchpad>/re_dl
    python -I import_ego.py index   "EGO/Faust/Representation Emitter"
    python -I import_ego.py sprites "EGO/Faust/Representation Emitter" --sheets <scratchpad>/re_sheets
    python -I import_ego.py zip     "EGO/Faust/Representation Emitter"

index, sprites y zip son los de import_identity.py (que ya distinguen un E.G.O por su EGO.xml): el que va al lado en el
zip de la skill o, en el repo, el de Claude/Skills/import-identity. Se ejecuta desde la raíz del repo de Bingus (o
BINGUS_REPO), como import_identity.py.

Requiere numpy, scipy y Pillow, y curl.
"""
from __future__ import annotations

import argparse
import re
import shutil
import sys
import urllib.parse
from pathlib import Path
from xml.sax.saxutils import escape

# import_identity.py: al lado (el zip de la skill lo lleva dentro) o en la skill hermana (en el repo). Con -I no se
# añade la carpeta del script a sys.path, así que se pone a mano.
_HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(d) for d in (_HERE, _HERE.parent / "import-identity") if (d / "import_identity.py").exists()]
import import_identity as ii  # noqa: E402
from import_identity import ATLAS_RE, EGO_ATLAS, REPO, ROOT, WIKI, download, ls, newest, wiki_download  # noqa: E402
from gif2sheet import to_json  # noqa: E402  (import_identity ya pone Python/ en sys.path)

GRADES = ("ZAYIN", "TETH", "HE", "WAW", "ALEPH")

# Arte: sufijo en Drive (<num>_<sufijo>) -> archivo del E.G.O. Comprobado por hash con Wishing Cairn y Crow's Eye View.
ART = [("awaken_info.png", "images/portrait.png"), ("awaken_profile.png", "images/profile.png"),
       ("cg.png", "images/thumb.png"), ("profile_summary.png", "images/summary.png"),
       ("erosion_info.png", "images/corrosion_portrait.png"),
       ("erosion_profile.png", "images/corrosion_profile.png"),
       (("e_cg.png", "cg_e.png"), "images/corrosion_thumb.png")]


def norm(name: str) -> str:
    """Para comparar nombres de carpeta: sin mayúsculas ni signos (Crow's / Crow’s)."""
    return re.sub(r"[^a-z0-9]", "", name.lower())


def find(folder: str | None, *names: str) -> str | None:
    """Como import_identity.cd, pero sin fijarse en signos ni apóstrofos. None si falta alguna."""
    for name in names:
        if folder is None:
            return None
        hit = [e for e in ls(folder) if e["dir"] and norm(e["name"]) == norm(name)]
        folder = hit[0]["id"] if hit else None
    return folder


#region new

def cmd_new(a) -> None:
    """Copia EGO/TEMPLATE/EGO.xml con su pecador, grado y nombre (como EgoDocument.CreateFromTemplate del editor)."""
    ego = Path(a.ego)
    if (ego / "EGO.xml").exists():
        print(f"{ego / 'EGO.xml'} ya existe: no se toca")
        return
    sinner, name = a.sinner or ego.resolve().parent.name, a.name or ego.name
    # En los atributos, escapados (un nombre con & o comillas no rompe el XML)
    attr = lambda v: escape(v, {'"': "&quot;"})
    xml = (REPO / "EGO/TEMPLATE/EGO.xml").read_text(encoding="utf-8")
    xml = re.sub(r'(<ego:EGO\b[^>]*?)grade="[^"]*"', rf'\1grade="{a.grade}"', xml, count=1)
    xml = re.sub(r'(<ego:EGO\b[^>]*?)sinner="[^"]*"', lambda m: f'{m.group(1)}sinner="{attr(sinner)}"', xml, count=1)
    # La plantilla está en EGO/TEMPLATE; el E.G.O, un nivel más abajo (EGO/<pecador>/<E.G.O>)
    xml = xml.replace('"http://bingus/schemas/ego ../../Schemas/EGO.xsd"', '"http://bingus/schemas/ego ../../../Schemas/EGO.xsd"')
    xml = re.sub(r'(<(?:Awakening|Corrosion)\b[^>]*?)name="[^"]*"', lambda m: f'{m.group(1)}name="{attr(name)}"', xml)
    # Las monedas, con su animation-id (EGO.md, "Animaciones"): s1c<n> en el Awakening
    n = iter(range(1, 100))
    xml = re.sub(r"<Coin\s*/>", lambda m: f'<Coin animation-id="s1c{next(n)}"/>', xml)
    ego.mkdir(parents=True, exist_ok=True)
    (ego / "EGO.xml").write_text(xml, encoding="utf-8")
    # Un sprites.json mínimo, con las claves de los otros E.G.O (uno vacío no lo abre el Animator). Lo rellena index
    sprites = ego / "sprites.json"
    if not sprites.exists() or not sprites.read_text(encoding="utf-8").strip():
        sprites.write_text(to_json({
            "atlases": {},
            "sprites": {"comment": "rect = [x, y, ancho, alto] en su atlas. Todavía sin piezas: las pone sprites."},
            "sfx": {"comment": "Sonidos con nombre (ver animations.md). Todavía sin indexar: los pone index."},
            "voice": {"comment": "Voces con nombre, por el canal de voz (ver animations.md). Todavía sin indexar: las "
                                 "pone index."},
            "animations": {"comment": ii.EGO_ANIMATIONS_COMMENT}}).replace("{  }", "{}") + "\n", encoding="utf-8")
    print(f"{ego}: EGO.xml ({sinner}, {a.grade}, {name}) y un sprites.json sin nada. Las stats, con el editor de IDs.")

#endregion


#region fetch

def pick_ego_atlases(files: list[dict]) -> tuple[list[dict], list[dict]]:
    """
    Los atlas de un E.G.O: agrupados por juego (nombre + hash, con todas sus hojas sactx-N) y por skill
    (SD_Skill_<n.º><skill><hoja>: 1 el Awakening, 2 la Corrosion). De cada skill, el juego más nuevo. Las piezas que
    se le añadieron luego (SD_Skill_2080111_Add) son otro juego aparte de la misma skill, y también se bajan.
    """
    sets: dict[tuple[str, str], list[dict]] = {}
    for f in files:
        if (m := ATLAS_RE.match(f["name"])) and EGO_ATLAS.search(m.group(4)):
            sets.setdefault((m.group(4), m.group(5)), []).append(f)
    date = {k: max(f["date"] for f in v) for k, v in sets.items()}
    by_skill: dict[tuple[str, str | None], list[tuple[str, str]]] = {}
    for k in sets:
        by_skill.setdefault(EGO_ATLAS.search(k[0]).groups(), []).append(k)
    chosen = [f for ks in by_skill.values() for f in sets[max(ks, key=date.get)]]
    return chosen, [f for f in files if f not in chosen]


def cmd_fetch(a) -> None:
    ego = Path(a.ego)
    if not (ego / "EGO.xml").exists():
        sys.exit(f"{ego} no tiene EGO.xml: primero `new`")
    dl = Path(a.dl)
    sinner, name = a.sinner or ego.resolve().parent.name, a.name or ego.name
    report: list[str] = []
    missing: list[str] = []
    copied: list[tuple[Path, Path]] = []

    def get(entry: dict, rel: str) -> None:
        tmp = dl / "drive" / rel
        download(entry["id"], tmp)
        copied.append((tmp, ego / rel))

    images = find(ROOT, "Images")
    audio = find(ROOT, "Audio")

    # Arte: <num>_awaken_info, _awaken_profile, _cg, _profile_summary y, si tiene Corrosion, los erosion y el e_cg
    art = find(images, "Identity & EGO Art", sinner, "EGO", name)
    art_files = [f for f in (ls(art) if art else []) if not f["dir"]]
    if not art:
        missing.append(f"Images/Identity & EGO Art/{sinner}/EGO/{name}/")
    num = a.num or next((m.group(1) for f in art_files if (m := re.match(r"(\d{5})_awaken_profile\.png$", f["name"]))),
                        None) or next((m.group(1) for f in art_files if (m := re.match(r"(\d{5})_", f["name"]))), None)
    corrosion = any(re.fullmatch(rf"{num}_erosion_\w+\.png", f["name"]) for f in art_files)
    for suffixes, dest in ART:
        if "corrosion_" in dest and not corrosion:
            continue
        suffixes = (suffixes,) if isinstance(suffixes, str) else suffixes
        best, rest = newest([f for f in art_files if any(f["name"] == f"{num}_{s}" for s in suffixes)])
        if best:
            get(best, dest)
            report += [f"  descartado ({dest}): {f['name']} ({f['date']})" for f in rest]
        else:
            missing.append(f"Identity & EGO Art/{sinner}/EGO/{name}/{num}_{suffixes[0]}")

    # Atlas: solo el primer nivel (la subcarpeta A/ son piezas sueltas), el juego más nuevo de cada skill
    spr = find(images, "Sprites", "Sinners", sinner, "EGO", name)
    spr_files = [f for f in (ls(spr) if spr else []) if not f["dir"]]
    chosen, rest = pick_ego_atlases([f for f in spr_files if ATLAS_RE.match(f["name"])])
    for f in chosen:
        get(f, f"images/sprites/{f['name']}")
    report += [f"  descartado (atlas): {f['name']} ({f['date']})" for f in rest]
    report += [f"  sin bajar (sprites): {f['name']}" for f in spr_files if not ATLAS_RE.match(f["name"])]
    if not chosen:
        missing.append(f"Sprites/Sinners/{sinner}/EGO/{name}/sactx-*.png")

    # Sonidos y voces: todos los .wav de su carpeta
    for branch, sub in (("Sound Effects", "sfx"), ("Voicefiles", "voice")):
        folder = find(audio, branch, "Sinners", sinner, "EGO", name)
        wavs = [f for f in (ls(folder) if folder else []) if not f["dir"] and f["name"].lower().endswith(".wav")]
        for f in wavs:
            get(f, f"sound/{sub}/{f['name']}")
        if not wavs:
            missing.append(f"Audio/{branch}/Sinners/{sinner}/EGO/{name}/*.wav")

    # Wiki: el gif del idle de la Corrosion (no va al zip; se hace la hoja con gif2sheet)
    if corrosion:
        gif = f"Corrosion_{name}_{sinner}_Idle_Animation.gif".replace(" ", "_")
        tmp = dl / "wiki" / gif
        if wiki_download(urllib.parse.quote(gif), tmp):
            copied.append((tmp, ego / "images/sprites" / gif))
        else:
            missing.append(WIKI + urllib.parse.quote(gif))
    else:
        report.append("  sin Corrosion (no hay arte erosion_*): ni su arte ni el gif de su idle")

    for src, dst in copied:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(src, dst)
        print("  +", dst.relative_to(ego).as_posix())
    print(f"n.º {num}, {len(copied)} archivos")
    if report:
        print("\n".join(report))
    if missing:
        print("No encontrado:\n  " + "\n  ".join(missing))

#endregion


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    n = sub.add_parser("new", help="crea la carpeta con el EGO.xml de la plantilla (pecador, grado, nombre)")
    n.add_argument("ego", help="EGO/<pecador>/<E.G.O>")
    n.add_argument("--grade", required=True, choices=GRADES)
    f = sub.add_parser("fetch", help="baja los archivos de Drive y el gif de la wiki a la carpeta del E.G.O")
    f.add_argument("ego")
    f.add_argument("--dl", required=True, help="carpeta nueva del scratchpad para las descargas")
    f.add_argument("--num", help="n.º del E.G.O (20201); por defecto, el de su arte")
    for p in (n, f):
        p.add_argument("--sinner", help="pecador en Drive; por defecto, la carpeta de arriba")
        p.add_argument("--name", help="nombre del E.G.O en Drive; por defecto, el de su carpeta")
    i = sub.add_parser("index", help="atlases, sfx y voice en sprites.json")
    i.add_argument("identity", metavar="ego")
    s = sub.add_parser("sprites", help="todas las piezas de los atlas en sprites (y hojas de contacto)")
    s.add_argument("identity", metavar="ego")
    s.add_argument("--sheets", help="carpeta para las hojas de contacto")
    s.set_defaults(wiki_dir=None, max_score=0.12)
    z = sub.add_parser("zip", help="rehace el zip del E.G.O (pack_ego)")
    z.add_argument("identity", metavar="ego")
    a = ap.parse_args()
    {"new": cmd_new, "fetch": cmd_fetch, "index": ii.cmd_index, "sprites": ii.cmd_sprites, "zip": ii.cmd_zip}[a.cmd](a)


if __name__ == "__main__":
    main()
