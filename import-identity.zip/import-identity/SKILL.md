---
name: import-identity
description: Trae los archivos de una ID (arte, iconos de skills, atlas, sprite de muerto, sfx y voces) de la carpeta pública de Drive "Limbus Company - Organized Assets", los gifs de la wiki.gg, los indexa en su sprites.json (dead, idle, atlases, sprites, sfx, voice) y rehace el zip. Úsala al empezar una ID nueva cuya carpeta solo tiene la plantilla.
---

# Importar los archivos de una ID

Antes de nada, lee `forbidden.md` y `animations.md` (formato de `sprites.json`). Las animaciones (`animations`) no son parte de esto: se hacen luego con el Animator (`Animator.md`).

Las rutas de esta skill (`forbidden.md`, `Python/gif2sheet.py`, `EGO/TEMPLATE`...) son desde la raíz del repo de Bingus, no desde la carpeta de la skill: puede estar instalada fuera del repo, desde su zip.

## De dónde sale cada cosa

**El conector de Google Drive no sirve**: solo ve las carpetas que el usuario ya ha abierto, y ni siquiera los archivos de dentro. La carpeta es pública y se lee sin login:

- Listar: `https://drive.google.com/embeddedfolderview?id=<carpeta>` (nombre, id y fecha de cada entrada).
- Bajar: `https://drive.google.com/uc?export=download&id=<archivo>`.
- Raíz: `1Nk9WWMxEcovs5Ewku5ICT1PbfByNcV_z`.

`<num>` es el número de la ID (LCB Sinner de Ishmael: `10801`; de Hong Lu, `10601`). `<idf>` es su carpeta en Drive (`LCB Sinner`).

| En la ID | En Drive | Notas |
|---|---|---|
| `images/profile.png` | Images/Identity & EGO Art/`<Pecador>`/Identities/`<idf>`/`<num>_gacksung_profile.png` | Comprobado por hash con Hong Lu. |
| `images/portrait.png` | …/`<num>_normal_info.png` | |
| `images/thumb.png` | …/`<num>_normal.png` | |
| `images/skills/<num>01..03.png`, `<num>04_4.png` | Images/Icons/Skills/Sinners/`<Pecador>`/`<idf>`/ | La de guardia, la `_4` (uptie 4) si existe; si no, la normal (Heathcliff). |
| `images/sprites/sactx-*.png` | Images/Sprites/Sinners/`<Pecador>`/Identities/`<idf>`/ | **Solo el primer nivel**: la subcarpeta `<num>_..._BaseAppearance` son sprites sueltos y no se usan (se usan los atlas). Tampoco `<num>.png` ni `skeleton*.png`. |
| `images/sprites/dead*.png` | Images/Sprites/Sinners/`<Pecador>`/ | |
| `sound/sfx/` | Audio/Sound Effects/Sinners/`<Pecador>`/Identities/`<idf>`/ | Los `<pecador>_N_M.wav`. Los `NNN_<pecador>_base_skillN_a_v1.wav` no (ninguna ID los lleva). |
| `sound/voice/` | Audio/Voicefiles/Sinners/`<Pecador>`/Identities/`<idf>`/ | `formation`, `battle_select`, `battle_endcommand`, `battle_break`, `battle_enemy_break`, `battle_kill`, `battle_s2`, `battle_s3`, `battleentry` (`_<num>_*.wav`). No lobby, smalltalk, choice… |
| `images/sprites/<wiki>_Idle_Animation.gif`, `<wiki>_Skill_1..3.gif` | wiki.gg, `https://limbuscompany.wiki.gg/images/<archivo>` | El idle se convierte en hoja; los de skills son el fondo del Animator. No van al zip. Algunas IDs usan otro nombre (Heathcliff: `_Remember_Skill_N`): si no los encuentra, búscalo o pídeselo al usuario. |
| (scratchpad) `<wiki>_Guard/Evade/Hurt/Moving/Idle_Sprite.png` | wiki.gg | Solo para reconocer las poses comunes en los atlas. |

`<wiki>` es el prefijo de la wiki: `LCB_Sinner_Ishmael`, `LCB_Sinner_Hong_Lu`. La wiki se baja con `curl` **tal cual, sin cabecera de navegador** (con `-A "Mozilla/..."` da 403). Nunca la de Fandom.

**Versiones:** si hay varias del mismo archivo, **siempre la más reciente** (por la fecha de la vista pública): son actualizaciones o rediseños. Los atlas se agrupan por juego (nombre + hash, con todas sus hojas `sactx-N`): de cada papel (`Base_Common`, `S1`, `S2`…) el juego más nuevo, y si hay un atlas del personaje entero más nuevo que todos ellos, es un rediseño y los sustituye (Heathcliff: `Heathcliff_cp6_Base_atlas`, del 1/5/24, en vez de los `Crunch-S1/S2/S3/Base_Common` del 5/3/23). Si empatan en fecha, también gana el atlas entero (Outis: `Base_SDAtlas`, que trae además una pieza que no está en los otros). Si el usuario sabe de un rediseño que no está en ese primer nivel (los atlas `CP9` de Ryoshu no están ahí), pregúntale de dónde sacarlo.

## La herramienta: `import_identity.py`

`<skill>` es la carpeta de esta skill (la de este `SKILL.md`: el "Base directory" que sale al cargarla), esté en el repo (`Claude/Skills/...`) o instalada desde su zip (`~/.claude/skills/...`). El script busca el repo subiendo desde la carpeta actual, así que se ejecuta **desde la raíz del repo** (o con su ruta en la variable `BINGUS_REPO`).

Necesita un Python 3 con `numpy`, `scipy` y Pillow, y `curl` (viene con Windows 10/11). Antes del primer paso, `python -c "import numpy, scipy, PIL"`; si falla, prueba con `py` o `python3` (en un PC puede haber varios Python y solo uno con ellos), y si ninguno los tiene, pídele al usuario que los instale (`python -m pip install numpy scipy pillow`). Con `-I` y 2-3 minutos como mucho por paso:

```
python -I "<skill>/import_identity.py" fetch   "Identities/Ishmael/LCB Sinner Ishmael" --sinner Ishmael --num 10801 --wiki LCB_Sinner_Ishmael --dl "<scratchpad>/<id>_dl"
python -I "<skill>/import_identity.py" index   "Identities/Ishmael/LCB Sinner Ishmael"
python -I "<skill>/import_identity.py" sprites "Identities/Ishmael/LCB Sinner Ishmael" --wiki-dir "<scratchpad>/<id>_dl/wiki" --sheets "<scratchpad>/sheets"
python -I "<skill>/import_identity.py" zip     "Identities/Ishmael/LCB Sinner Ishmael"
```

- **`fetch`**: baja a `--dl` (una carpeta nueva del scratchpad), comprueba la cabecera (PNG, WAV, GIF) y copia a la ID. Al final, lo descartado (versiones viejas, sfx `NNN_`) y lo que no ha encontrado. `--id-folder` si la carpeta de la ID en Drive no es `LCB Sinner`. Si Drive o la wiki bloquean (403, 429), **no hay que saltárselo**: para y pásale al usuario los enlaces y dónde guardarlos.
- **`index`**: escribe en `sprites.json` `dead`, `atlases` (`common`, `s1`, `s2`, `s3`; la hoja `sactx-1` de un papel, `s3b`; un atlas del personaje entero, `a0`, `a1`…), `sfx` (`ishmael_3_2.wav` → `s3_2`, `honglu_3_2-1.wav` → `s3_2_1`; `clash_sfx` = el primero de S1 y el de S2) y `voice` (las de la partida con su nombre; las de skills `s2`, `s3`, o `s3_1`, `s3_2`… si hay varias, en orden). Deja `idle`, `sprites` y `animations` como estén, y las claves en el orden de las otras IDs. Si dos juegos de atlas (otro hash) dan el mismo nombre corto (Ryoshu tiene dos `CP9_Atlas`), se queda el que ya está en `atlases` o, si no hay, el archivo más nuevo, y lo avisa.
- **`sprites`**: todas las piezas de los atlas, como las corta el cliente (alfa > 6, engordado 3 px, componentes de 4 vecinos, de 2000 píxeles opacos o más), con su `rect`, ordenadas de arriba abajo: `<atlas>_<n>`. Las 5 comunes las reconoce comparando con los `_Sprite` de la wiki (derecha o girada 180°, espejada o no): da el nombre y `rotated`. Si casa espejada, `facing: "left"` (el `_Sprite` mira a la derecha); provisional, como todos. Lista las motas descartadas. Hace falta haber hecho antes `index` (sin `atlases`, para con un error).
  - **Junta, no pisa**: lo que ya está en `sprites` se queda tal cual (nombres, `pivot`, `rotated`, `facing`, las piezas partidas a mano, `stand`/`guard`…) y solo añade, detrás, las piezas que no cubre ninguna entrada (una entrada cubre la pieza de la que tiene más píxeles opacos en su `rect`: así cuentan las mitades de una pieza partida a mano, y no las vecinas que asoman). Las nuevas se llaman como siempre (`<atlas>_<n>`, el primer `n` libre; una pose común que falte, por su nombre). Una entrada cuyo atlas ya no está, o cuyo `rect` se sale de él o está vacío, se queda también, con un aviso: se arregla o se quita a mano. El `comment` no lo toca (si ya hay uno).
  - Deja una hoja de contacto por atlas en `--sheets` con todas (las piezas ya derechas; `R` = rotated, `L`/`R` = facing, `+` = nueva).
- **`zip`**: rehace `<ID>.zip` con `identity.xml`, `sprites.json`, `images/` y `sound/`, sin los gifs ni `idle.json`.

## Un E.G.O

Un E.G.O (`EGO/<pecador>/<E.G.O>/`, con `EGO.xml`) se importa con su propia skill, `import-ego`: crea la carpeta desde la plantilla, baja sus archivos de Drive y el gif del idle de su Corrosion, y usa los `index`, `sprites` y `zip` de aquí (que distinguen un E.G.O por su `EGO.xml`: atlas `s1`/`s2`, sin `dead` ni poses comunes, el zip con `pack_ego.py`).

## Proceso para una ID

1. `fetch`. Si falta algo, mira la carpeta a mano (`embeddedfolderview`) por si el nombre cambia.
2. `index` y `sprites`.
3. **Revisar las piezas a ojo** (la herramienta no sabe hacia dónde miran ni si las de skills están giradas):
   - Mira las hojas de contacto. Las que salen boca abajo llevan `rotated: true`. Si dudas, saca la pieza grande, tal cual y girada, y compárala con los gifs de las skills (en Ishmael, las de S2 van tumbadas y solo se aclaran con el gif).
   - `facing`: hacia dónde mira una vez derecha. Fíjate en la cara y en el escudo o el arma (en Ishmael, el escudo va del lado al que mira).
   - El `stand` y el idle: compara con números el `stand` derecho con un fotograma del idle, tal cual y espejado. En Ishmael el `stand` es el idle espejado: mira a la izquierda.
   - Mira las motas más grandes antes de dejarlas fuera (suelen ser jirones de estelas o líneas de velocidad) y busca piezas repetidas o casi iguales.
   - Escribe todo en el `comment` de `sprites` (ver el de Hong Lu o Ishmael): método, motas, repetidas, partículas, `facing` provisional.
4. **Idle** con `Python/gif2sheet.py` (ver animations.md, "Crear el idle desde un gif"), desde la carpeta de la ID:
   `python -I ../../../Python/gif2sheet.py images/sprites/<wiki>_Idle_Animation.gif -o images/sprites/idle.png --scale <alto de stand / alto del fotograma> --facing <right|left> --into sprites.json --key idle`
   La escala suele ser 0.83 (Ishmael: 426 / 506 ≈ 0.84); compruébala siempre. Pinta un fotograma con los pies (`pivot`) al lado del `stand` para ver que cuadran; `--pivot` si el arma tapa un pie, `--head` si sobresale por arriba.
5. `zip`, y comprueba que todas las rutas del `sprites.json` están en el zip.
6. Comprueba que el Animator la carga: `SpriteSet("<ID>").load(...)` de `Bingus.Animator/bingus_anim/sprites.py`, sin errores. (Su `--selftest` necesita una skill con animación; una ID recién importada no tiene.)
7. No se toca `identity.xml` (stats, skills, `icon`), salvo que el usuario lo pida.
